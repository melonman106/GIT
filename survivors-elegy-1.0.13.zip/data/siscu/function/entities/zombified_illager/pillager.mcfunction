execute if entity @s[predicate=siscu:utils/is_baby] run return run tag @s remove siscu.zombified_pillager
tag @s add siscu.zombified_pillager

loot replace entity @s armor.chest loot siscu:items/combat/pillager_chestplate
loot replace entity @s armor.legs loot siscu:items/combat/pillager_leggings
loot replace entity @s[tag=!siscu.new_zombified] weapon.mainhand loot siscu:entities/zombified_illager/pillager_weapon

data modify entity @s VillagerData.profession set value "nitwit"

# drops
data merge entity @s {drop_chances:{chest:0.0,legs:0.0}}

#say pillager