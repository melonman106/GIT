
$summon minecraft:area_effect_cloud ^ ^ ^0.2 {Tags:["smithed.entity","siscu.honey_display"],WaitTime:0,Duration:21,CustomName:[{"text":"$(bees)","font":"siscu_se:bee_count"},{"text":"$(honey_level)","font":"siscu_se:bee_count"}],CustomNameVisible:true,Radius:0}
