# Tag the entity as checked

tag @s add siscu.drowned_checked

# Run the randomiser
execute store success score x siscu.volatile run execute on vehicle if entity @s
execute unless score x siscu.volatile matches 0 run loot replace entity @s weapon loot siscu:entities/drowned/drowned_weapons
execute if predicate siscu:utils/10_percent run loot replace entity @s armor.head loot siscu:entities/drowned/drowned_helmets
execute if predicate siscu:utils/10_percent run loot replace entity @s armor.chest loot siscu:entities/drowned/drowned_chestplates
execute if predicate siscu:utils/20_percent if predicate siscu:entities/is_wearing_copper_chestplate run loot replace entity @s armor.legs loot siscu:entities/drowned/drowned_leggings
execute if predicate siscu:utils/10_percent run loot replace entity @s armor.feet loot siscu:entities/drowned/drowned_boots

execute if predicate siscu:entities/is_holding_trident if predicate siscu:utils/is_baby run data merge entity @s {drop_chances:{mainhand:0.0,offhand:0.0}}

execute if items entity @s armor.* #siscu:armor_items/copper if predicate siscu:utils/50_percent run function siscu:items/passive_behav/charge/copper_armor